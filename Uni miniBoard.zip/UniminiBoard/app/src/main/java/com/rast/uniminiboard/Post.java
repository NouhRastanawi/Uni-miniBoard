package com.rast.uniminiboard;

public class Post {
    private String date;
    private String title;
    private String content;
}
