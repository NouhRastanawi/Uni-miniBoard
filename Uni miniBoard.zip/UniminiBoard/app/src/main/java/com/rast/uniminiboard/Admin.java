package com.rast.uniminiboard;

public class Admin {

}
