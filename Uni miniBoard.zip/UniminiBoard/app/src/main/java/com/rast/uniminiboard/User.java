package com.rast.uniminiboard;

public class User {

    private String faculty;

}
