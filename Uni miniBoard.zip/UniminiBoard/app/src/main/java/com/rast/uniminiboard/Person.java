package com.rast.uniminiboard;

public abstract class Person {
    protected String name;
    protected String id;
    protected String password;
    protected String email;
}
