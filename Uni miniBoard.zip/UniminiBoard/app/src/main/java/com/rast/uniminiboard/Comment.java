package com.rast.uniminiboard;

public class Comment {
    private String date;
    private String content;
}
